#include "ResponseParser.hpp"
#include <iostream>
#include "http/Parser/Parser.hpp"
#include <cstdlib>
#include <cerrno>
#include <fcntl.h>
#include <unistd.h>

namespace http {

ResponseParser::ResponseParser()
    : state_(Headers),
      code(OK),
      headers_(),
      parse_ctx(),
      body_fd(-1),
      body_filename(),
      body_content_length(0),
      body_(),
      body_mode_(Mem),
      chunked_(false),      // NEW
      dechunker_() {}       // NEW

ResponseParser::~ResponseParser() {
    if (body_fd >= 0) {
        ::close(body_fd);
        body_fd = -1;
    }

    if (!body_filename.empty()) ::unlink(body_filename.c_str());

    body_filename.clear();
}

// ─────────────────────────────────────────────────────────────────────────────
// parse()  — unchanged from original except for the constructor additions above
// ─────────────────────────────────────────────────────────────────────────────
ResponseParser::ParseResult ResponseParser::parse(BufferView& reader) {
    std::cout << "Start CGI header parsing...\n";

    if (reader.empty() && state_ == Headers) {
        return ParseError;
    }

    while (state_ != Done) {

        if (state_ == Body) return read_body(reader);

        size_t max_scan_size = CGIParseContext::MaxHeaderBlockLen - parse_ctx.header_bytes;

        ReadResult r = parse_ctx.line_reader.readline(reader, max_scan_size);
        reader.advance(parse_ctx.line_reader.bytes_read());

        switch (r) {
            case LIMIT_EXCEEDED: return ParseError;
            case NEED_MORE:      return Continue;
            case SUCCESS:        break;
        }

        if (parse_ctx.line_reader.line().empty()) {
            if (!validate_headers()) return ParseError;
            std::cout << "Begin body reading\n";
            state_ = Body;
            continue;
        }

        parse_ctx.header_bytes += parse_ctx.line_reader.line().size();

        ParseResult res = parse_header(parse_ctx.line_reader.line());
        if (res != Success) return res;

        parse_ctx.line_reader.reset();
    }

    std::cout << "finish CGI\n";
    return Success;
}

// ─────────────────────────────────────────────────────────────────────────────
// parse_header()
// CHANGED: intercepts "transfer-encoding: chunked" to set chunked_ flag.
//          The header is consumed (not forwarded to headers_) so the client
//          never sees a Transfer-Encoding header in the final response.
// ─────────────────────────────────────────────────────────────────────────────
ResponseParser::ParseResult ResponseParser::parse_header(std::string const& line) {
    std::cout << "|" << line << "|\n";

    size_t colon = line.find(':');
    if (colon == std::string::npos)
        return ParseError;

    std::string name = base::toLowerCase(line.substr(0, colon));

    for (size_t i = 0; i < name.size(); ++i) {
        if (::isspace(static_cast<unsigned char>(name[i])))
            return ParseError;
    }

    size_t start = colon + 1;
    while (start < line.size() &&
           ::isspace(static_cast<unsigned char>(line[start]))) {
        ++start;
    }

    size_t end = line.size();
    while (end > start &&
           ::isspace(static_cast<unsigned char>(line[end - 1]))) {
        --end;
    }

    std::string value = line.substr(start, end - start);

    if (name == "status")
        return sanitize_status_header(value);

    // NEW: intercept chunked transfer-encoding
    if (name == "transfer-encoding") {
        std::string lower_value = base::toLowerCase(value);
        if (lower_value == "chunked") {
            chunked_ = true;
            return Success;   // consumed; not forwarded to headers_
        }
        // Any other transfer-encoding (gzip, compress, …) is unsupported at
        // the CGI layer — the server is not a decode pipeline.
        return ParseError;
    }

    headers_.add(name, value);
    return Success;
}

// ─────────────────────────────────────────────────────────────────────────────
// sanitize_status_header() — unchanged
// ─────────────────────────────────────────────────────────────────────────────
ResponseParser::ParseResult ResponseParser::sanitize_status_header(std::string const& value) {
    std::cout << "Sanitising status header\n";

    size_t space_pos = value.find(' ');
    if (space_pos == std::string::npos) {
        code = INTERNAL_SERVER_ERROR;
        return ParseError;
    }

    std::string code_str = value.substr(0, space_pos);

    for (size_t i = 0; i < code_str.size(); ++i) {
        if (!std::isdigit(code_str[i])) {
            code = INTERNAL_SERVER_ERROR;
            return ParseError;
        }
    }

    char* end = NULL;
    int parsed_code = std::strtol(code_str.c_str(), &end, 10);

    if ((end && *end != '\0') || parsed_code < 200 || parsed_code > 599) {
        code = INTERNAL_SERVER_ERROR;
        return ParseError;
    }

    code = static_cast<http::StatusCode>(parsed_code);
    return Success;
}

// ─────────────────────────────────────────────────────────────────────────────
// write_body_bytes()  NEW helper
//
// Unified sink for both chunked and non-chunked body bytes.
// Handles the Mem→Disk threshold and loops on partial disk writes.
// body_content_length is incremented here for BOTH modes so callers can
// always rely on it for the total byte count regardless of storage mode.
// ─────────────────────────────────────────────────────────────────────────────
ResponseParser::ParseResult
ResponseParser::write_body_bytes(const char* data, std::size_t len) {
    if (len == 0) return Continue;

    // ── Memory path ──────────────────────────────────────────────────────────
    if (body_mode_ == Mem) {
        if (body_.size() + len <= MaxBodyMemSize) {
            body_.append(data, len);
            body_content_length += len;
            return Continue;
        }
        // Threshold crossed: promote to disk
        body_mode_ = Disk;
    }

    // ── Disk path ────────────────────────────────────────────────────────────
    if (body_fd < 0) {
        body_filename = "/tmp/" + base::random_string(10);
        body_fd = ::open(body_filename.c_str(),
                         O_WRONLY | O_CREAT | O_TRUNC, 0600);
        if (body_fd < 0) {
            state_ = Error;
            return ParseError;
        }

        // Flush whatever was accumulated in memory first.
        // These bytes were already counted in body_content_length.
        if (!body_.empty()) {
            const char* p   = body_.c_str();
            std::size_t rem = body_.size();
            while (rem > 0) {
                ssize_t w = ::write(body_fd, p, rem);
                if (w < 0) {
                    if (errno == EINTR) continue;
                    state_ = Error;
                    return ParseError;
                }
                p   += w;
                rem -= static_cast<std::size_t>(w);
            }
            body_.clear();
        }
    }

    // Write new bytes to disk, looping on partial writes / EINTR.
    const char* p   = data;
    std::size_t rem = len;
    while (rem > 0) {
        ssize_t w = ::write(body_fd, p, rem);
        if (w < 0) {
            if (errno == EINTR) continue;
            state_ = Error;
            return ParseError;
        }
        p   += w;
        rem -= static_cast<std::size_t>(w);
    }
    body_content_length += len;
    return Continue;
}

// ─────────────────────────────────────────────────────────────────────────────
// read_body()
// CHANGED:
//   • Delegates to write_body_bytes() instead of duplicating Mem/Disk logic.
//   • When chunked_ is true, feeds reader through the Dechunker first;
//     completion is signaled by the terminal 0-chunk (not by an empty reader).
//   • On dechunking completion adds a Content-Length header computed from
//     body_content_length so the client receives a proper framed response.
// ─────────────────────────────────────────────────────────────────────────────
ResponseParser::ParseResult ResponseParser::read_body(BufferView& reader) {

    // ── Chunked path ─────────────────────────────────────────────────────────
    if (chunked_) {
        // An empty reader while still waiting for the terminal chunk means
        // the CGI closed stdout prematurely — that is a protocol error.
        if (reader.empty()) {
            state_ = Error;
            return ParseError;
        }

        std::string dechunked;
        Dechunker::Result dr = dechunker_.process(reader, dechunked);

        if (dr == Dechunker::Error) {
            state_ = Error;
            return ParseError;
        }

        if (!dechunked.empty()) {
            ParseResult pr = write_body_bytes(dechunked.data(), dechunked.size());
            if (pr == ParseError) return ParseError;
        }

        if (dr == Dechunker::Done) {
            // Now that the full body is known, materialise Content-Length.
            // Remove any CGI-supplied content-length first to avoid duplicates
            // (a broken CGI might send both Transfer-Encoding and Content-Length).
            headers_.remove("content-length");
            headers_.add("content-length", std::to_string(body_content_length));
            state_ = Done;
            return Success;
        }

        return Continue;
    }

    // ── Non-chunked path ─────────────────────────────────────────────────────
    // Completion is signalled externally: the caller passes an empty reader
    // once the pipe reaches EOF.
    if (reader.empty()) {
        std::cout << "Body Done\n";
        state_ = Done;
        return Success;
    }

    std::size_t to_write = reader.remaining();
    ParseResult pr = write_body_bytes(reader.data(), to_write);
    if (pr == ParseError) return ParseError;

    reader.advance(to_write);   // all bytes were consumed (write_body_bytes loops)
    return Continue;
}

// ─────────────────────────────────────────────────────────────────────────────
// finished() — unchanged
// ─────────────────────────────────────────────────────────────────────────────
bool ResponseParser::finished() const {
    return state_ == Done;
}

// ─────────────────────────────────────────────────────────────────────────────
// result() — unchanged
// Content-Length was already added to headers_ inside read_body() for the
// chunked case, so result() needs no special-casing.
// ─────────────────────────────────────────────────────────────────────────────
CGIResult ResponseParser::result() const {

    if (body_mode_ == Mem) return CGIResult(body_, code, headers_);

    if (body_fd >= 0) {
        ::close(body_fd);
        body_fd = -1;
    }

    std::string temp = body_filename;
    body_filename.clear();

    return CGIResult(temp, body_content_length, code, headers_);
}

// ─────────────────────────────────────────────────────────────────────────────
// validate_headers() — unchanged
// ─────────────────────────────────────────────────────────────────────────────
bool ResponseParser::validate_headers() const {
    if (headers_.get("content-type").empty() &&
        headers_.get("location").empty()) return false;
    return true;
}

} // namespace http
