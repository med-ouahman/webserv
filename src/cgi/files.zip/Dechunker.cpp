#include "Dechunker.hpp"
#include "BufferView.hpp"   // adjust path to match your project
#include <cctype>
#include <cstdlib>
#include <algorithm>

namespace http {

Dechunker::Dechunker()
    : state_(SIZE),
      size_buf_(),
      chunk_size_(0),
      chunk_read_(0) {}

void Dechunker::reset() {
    state_      = SIZE;
    chunk_size_ = 0;
    chunk_read_ = 0;
    size_buf_.clear();
}

bool Dechunker::parse_chunk_size() {
    if (size_buf_.empty()) return false;

    char* end = nullptr;
    unsigned long val = std::strtoul(size_buf_.c_str(), &end, 16);

    // strtoul sets end == c_str() when no valid digits are found
    if (!end || end == size_buf_.c_str()) return false;

    chunk_size_ = static_cast<std::size_t>(val);
    chunk_read_ = 0;
    size_buf_.clear();
    return true;
}

// Chunked wire format:
//
//   <hex-size> [ ";" chunk-ext ] CRLF
//   <chunk-data> CRLF
//   ...
//   0 CRLF
//   CRLF            ← trailing empty line terminates the body
//
Dechunker::Result Dechunker::process(BufferView& reader, std::string& out) {
    while (!reader.empty()) {
        switch (state_) {

            // ── SIZE ──────────────────────────────────────────────────────
            case SIZE: {
                char c = *reader.data();
                if (std::isxdigit(static_cast<unsigned char>(c))) {
                    size_buf_ += c;
                    reader.advance(1);
                    // Guard against absurdly large size fields
                    if (size_buf_.size() > 16) return Error;
                } else if (c == ';' || c == ' ' || c == '\t') {
                    // Chunk extension starts here; parse what we have, then skip
                    if (!parse_chunk_size()) return Error;
                    reader.advance(1);
                    state_ = SIZE_SKIP;
                } else if (c == '\r') {
                    if (!parse_chunk_size()) return Error;
                    reader.advance(1);
                    state_ = SIZE_LF;
                } else {
                    return Error;
                }
                break;
            }

            // ── SIZE_SKIP (chunk-extension) ───────────────────────────────
            case SIZE_SKIP: {
                char c = *reader.data();
                reader.advance(1);
                if (c == '\r') state_ = SIZE_LF;
                // Any other character is part of the extension, keep skipping
                break;
            }

            // ── SIZE_LF ──────────────────────────────────────────────────
            case SIZE_LF: {
                char c = *reader.data();
                reader.advance(1);
                if (c != '\n') return Error;
                state_ = (chunk_size_ == 0) ? FINAL_CR : DATA;
                break;
            }

            // ── DATA ─────────────────────────────────────────────────────
            case DATA: {
                // Consume as many bytes as available without going past the chunk boundary
                std::size_t remaining_in_chunk = chunk_size_ - chunk_read_;
                std::size_t to_copy = std::min(remaining_in_chunk, reader.remaining());
                out.append(reader.data(), to_copy);
                reader.advance(to_copy);
                chunk_read_ += to_copy;
                if (chunk_read_ == chunk_size_) state_ = DATA_CR;
                break;
            }

            // ── DATA_CR ──────────────────────────────────────────────────
            case DATA_CR: {
                char c = *reader.data();
                reader.advance(1);
                if (c != '\r') return Error;
                state_ = DATA_LF;
                break;
            }

            // ── DATA_LF ──────────────────────────────────────────────────
            case DATA_LF: {
                char c = *reader.data();
                reader.advance(1);
                if (c != '\n') return Error;
                state_ = SIZE;   // ready for next chunk
                break;
            }

            // ── FINAL_CR (trailing CRLF after the 0-chunk) ───────────────
            case FINAL_CR: {
                char c = *reader.data();
                reader.advance(1);
                if (c != '\r') return Error;
                state_ = FINAL_LF;
                break;
            }

            // ── FINAL_LF ─────────────────────────────────────────────────
            case FINAL_LF: {
                char c = *reader.data();
                reader.advance(1);
                if (c != '\n') return Error;
                state_ = DONE;
                return Done;
            }

            case DONE:
                return Done;
        }
    }

    return (state_ == DONE) ? Done : Continue;
}

} // namespace http
