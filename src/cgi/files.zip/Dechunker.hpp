#pragma once

#include <cstddef>
#include <string>

namespace http {

class BufferView;

// Parses HTTP chunked transfer encoding and emits raw body bytes.
// Feed it data incrementally; when it returns Done, all chunk data
// has been written to `out` and the terminal 0-chunk has been consumed.

class Dechunker {
public:
    enum Result {
        Done,       // Terminal zero-chunk received, dechunking complete
        Continue,   // Incomplete, call again with more data
        Error       // Malformed chunked encoding
    };

    Dechunker();

    // Process chunked bytes from reader, appending raw body bytes to out.
    // Reader is advanced by the number of bytes consumed.
    Result process(BufferView& reader, std::string& out);

    void reset();

private:
    enum State {
        SIZE,       // Reading hex digits of chunk size
        SIZE_SKIP,  // Skipping chunk-extension (after ';') until \r
        SIZE_LF,    // Consumed \r after size line, expecting \n
        DATA,       // Reading chunk-data bytes
        DATA_CR,    // All chunk data consumed, expecting \r
        DATA_LF,    // Consumed \r after data, expecting \n
        FINAL_CR,   // Zero-chunk seen, expecting \r of trailing CRLF
        FINAL_LF,   // Consumed \r of trailing CRLF, expecting \n
        DONE
    };

    State       state_;
    std::string size_buf_;      // Accumulates hex digit characters
    std::size_t chunk_size_;    // Decoded size of the current chunk
    std::size_t chunk_read_;    // Bytes of current chunk consumed so far

    // Parse size_buf_ as hex into chunk_size_, clear size_buf_.
    // Returns false if size_buf_ is empty or unparseable.
    bool parse_chunk_size();
};

} // namespace http
